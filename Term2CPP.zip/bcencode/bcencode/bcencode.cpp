#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <locale>
#include <vector>
using namespace std;

int main(int argc, char *argv[]) {
	vector<int> vRow;
	vector<int> vCol;

	if (argc < 4) {
		cout << "Error: Not enough arguments passed. Please enter bookfile, message file, and coded file in order." << endl;
		return EXIT_FAILURE;
	}

	ifstream message(argv[2]);
	if (!message) {
		cout << "Could not open message file" << endl;
		return EXIT_FAILURE;
	}

	ifstream book(argv[1]);
	if (!book) {
		cout << "Could not open book file" << endl;
	}

	ofstream encoded(argv[3]);
	if (!encoded) {
		cout << "Could not open the write file" << endl;
		return EXIT_FAILURE;
	}

	encoded.imbue(locale(""));

	char ch;
	char ch2;
	int row = 0;
	int col = 0;
	bool found;
	while (message.get(ch)) {
		found = false;
		while (book.get(ch2)) {
			col++;
			if (ch2 == ch) {
				vRow.push_back(row);
				vCol.push_back(col);
				encoded << row << "," << col << " ";
				found = true;
				if (ch2 == '\n') {
					row++;
					col = 0;
				}
				break;
			}
			if (ch2 == '\n') {
				row++;
				col = 0;
			}
		}
		if (found == false) {
			cout << "Error: character " << ch << " not found in book file." << endl;
			return EXIT_FAILURE;
		}
	}

	cout << endl;
	encoded.close();
	return EXIT_SUCCESS;
}