#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <locale>
#include <vector>
using namespace std;

int main(int argc, char *argv[]) {
	if (argc < 4) {
		cout << "Error: Not enough arguments passed. Please enter bookfile, coded file, and decoded message file in order.";
		return EXIT_FAILURE;
	}

	ifstream book(argv[1]);
	if (!book) {
		cout << "Error: could not open book file." << endl;
		return EXIT_FAILURE;
	}

	ifstream encoded(argv[2]);
	if (!encoded) {
		cout << "Error: could not open encoded file." << endl;
		return EXIT_FAILURE;
	}

	ofstream message(argv[3]);
	if (!message) {
		cout << "error: could not open file for writing." << endl;
		return EXIT_FAILURE;
	}

	int row;
	char ch;
	int col;

	vector<int> vRow;
	vector<int> vCol;

	if (encoded.is_open()) {
		while (encoded >> row >> ch >> col) {
			vRow.push_back(row);
			vCol.push_back(col);
		}
		encoded.close();
	}

	int bookRow = 0;
	int bookCol = 0;

	int r = 0;
	int c = 0;

	while (book.get(ch)){
		bookCol++;
		if (bookRow == vRow[r] && bookCol == vCol[c]) {
			message << ch;
			r++;
			c++;
			if (r == vRow.size() && c == vCol.size())
				break;
		}
		if (ch == '\n') {
			bookRow++;
			bookCol = 0;
		}
	}

	cout << endl;

	return EXIT_SUCCESS;
}