/* file - FileUsage.cpp
   author - Zach Francis
   date - 4/15/2019
   purpose - lists file usage, counts files, totals file sizes, and groups files by extension
*/

#include<locale>
#include<iostream>
#include<fstream>
#include<filesystem>
#include<algorithm>
#include<regex>
#include<iomanip>
#include<vector>
using namespace std;
using namespace std::experimental::filesystem;

//scans the directory and inserts them into a path vector
void scan_folders(path const &f);

//lists file types found, number of each, and the size in bytes
void print_result();

vector<path> files; //holds all the files found in the directory
vector<path> extensions; //holds the extensions of the files

//Regex to compare to switch command line arguement
regex cSwitch(".*c.*");
regex plusSwitch(".*\\+.*");
regex jSwitch(".*j.*");
regex sharpSwitch(".*#.*");
regex wSwitch(".*w.*");
regex xSwitch(".*x.*");
regex sSwitch(".*s.*");
regex rSwitch(".*r.*");
regex RSwitch(".*R.*");
regex SSwitch(".*S.*");
regex vSwitch(".*r.*");
regex hSwitch(".*h.*");

//booleans turn true if corresponding switch is found
bool c = false;
bool plusBool = false;//get an error in main if it's just called 'plus'
bool j = false;
bool sharp = false;
bool w = false;
bool x = false;
bool s = false;
bool r = false;
bool R = false;
bool S = false;
bool v = false;
bool h = false;

int main(int argc, char *argv[]) {
	path folder;

	//if (argc == 2) {
	//	folder = argv[1];
	//	if (!is_directory(folder)) {
	//		cout << "Error: <" << argv[1] << "> is not a directory or does not exist" << endl;
	//		return EXIT_FAILURE;
	//	}
	//}
	//else if (argc == 3) {
	//	folder = argv[2];
	//	if (!is_directory(folder)) {
	//		cout << "Error: <" << argv[2] << "> is not a directory or does not exist" << endl;
	//		return EXIT_FAILURE;
	//	}
	//	if (regex_match(argv[1], cSwitch))
	//		c = true;
	//	if (regex_match(argv[1], plusSwitch))
	//		plusBool = true;
	//	if (regex_match(argv[1], jSwitch))
	//		j = true;
	//	if (regex_match(argv[1], sharpSwitch))
	//		sharp = true;
	//	if (regex_match(argv[1], wSwitch))
	//		w = true;
	//	if (regex_match(argv[1], sSwitch))
	//		s = true;
	//	if (regex_match(argv[1], xSwitch))
	//		x = true;
	//	if (regex_match(argv[1], rSwitch))
	//		r = true;
	//	if (regex_match(argv[1], RSwitch))
	//		R = true;
	//	if (regex_match(argv[1], SSwitch))
	//		S = true;
	//	if (regex_match(argv[1], vSwitch))
	//		v = true;
	//	if (regex_match(argv[1], hSwitch))
	//		h = true;
	//}
	//else if (argc == 1) {
	//	cout << "too few arguements" << endl;
	//	return EXIT_FAILURE;
	//}
	//else if (argc > 3) {
	//	cout << "too many arguements" << endl;
	//	return EXIT_FAILURE;
	//}

	folder = L"."; //<- For testing purposes

	cout << "Reading From: " << current_path() << endl;

	cout.imbue(locale(""));//change locale to local
	scan_folders(folder);
	for (path p : files) {//write extensions to extensions vector
		extensions.push_back(p.extension());
	}

	sort(extensions.begin(), extensions.end());//sort extensions to make counting easier
	print_result();
	return EXIT_SUCCESS;
}

//scans the directory and inserts them into a path vector
void scan_folders(path const &f) {
	cout << "\n";
	for (recursive_directory_iterator d(f), e; d != e; ++d) {
		files.push_back(d->path());
	}
}

//lists file types found, number of each, and the size in bytes
void print_result() {
	int extCount = 1;
	uintmax_t fileSize = 0;
	int totalExtCount = 0;
	uintmax_t totalFileSize = 0;
	int totalTypes = 0;

	cout.width(20); cout << right << "Ext" << " : " << setw(5) << "#" << " : " << "Total" << endl;
	cout << "--------------------------------------------------------" << endl;
	for (unsigned i = 0; i < files.size(); ++i) {
		if (i == 0)
			continue;
		if(!is_directory(files[i]))
			fileSize = file_size(files[i]);
		if (!is_directory(files[i]) && extensions[i].compare(extensions[i - 1]) == 0) {
			fileSize += file_size(files[i]);
			++extCount;
		}
		else {
			cout.width(20); cout << extensions[i] << " : " << setw(5) << extCount << " : " << fileSize << endl;
			totalExtCount += extCount;
			totalFileSize += fileSize;
			++totalTypes;
			extCount = 1;
			fileSize = 0;
		}
	}
	cout << "--------------------------------------------------------" << endl;
	cout.width(20); cout << right << totalTypes << " : " << setw(5) << totalExtCount << " : " << totalFileSize;
}

void check_switches() {

}