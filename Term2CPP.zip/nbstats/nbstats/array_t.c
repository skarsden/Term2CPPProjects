/* File: array_t.c
   Purpose: Creates empty array object and functions
   Coder: Zach Francis */

#include "array_t.h"
#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


array_t array() {
	array_t array = { NULL, 0, 0 };
	return array;
}

bool array_push_back(array_t *pArray, array_value_t value) {
	//expand if necessary (always will be the first time)
	if (pArray->size == (*pArray).capacity) {
		//create new temp capacity to hold doubled capacity or increment in the case of an empty state
		size_t tempCapacity = pArray->capacity * 2;
		if (tempCapacity == 0)
			++tempCapacity;

		//memory allocation
		array_value_t *tempPtr = (array_value_t *)realloc(pArray->data, tempCapacity * sizeof(array_value_t));
		if (tempPtr == NULL)
			return false;

		//assign new values to object's attributes
		pArray->data = tempPtr;
		pArray->capacity = tempCapacity;
	}

	//add new value to object's array
	pArray->data[pArray->size] = value;
	++pArray->size;

	return true;
}

//memory is allocated using tempSize and maintains existing array
bool array_resize(array_t *pArray, size_t newSize) {
	//reset size to parameter
	if (newSize < pArray->size) {
		pArray->size = newSize;
		return true;
	}

	//expand if necessary
	if (newSize > pArray->size) {
		size_t newCapacity = newSize;
		if (newCapacity == 0)
			++newCapacity;

		array_value_t *newBlock = (array_value_t *)realloc(pArray->data, newCapacity * sizeof(array_value_t));
		if (newBlock == NULL)
			return false;

		pArray->data = newBlock;
		pArray->capacity = newCapacity;
	}

	//initialize any additional elements to 0
	while (pArray->size < newSize) {
		pArray->data[pArray->size] = 0;
		++pArray->size;
	}

	return true;
}

//sort_array: Sorts an array containing numeric values into ascending order. Accepts an array containing numeric data and returns the array sorted in ascending order
//Coder: Zach Francis
array_t sort_array(array_t copyArray) {
	array_value_t minValue = 0;
	size_t minValueIndex;

	for (size_t currentIndex = 0; currentIndex < copyArray.size; currentIndex++) {
		minValue = copyArray.data[currentIndex];
		minValueIndex = currentIndex;

		for (size_t nextIndex = currentIndex + 1; nextIndex < copyArray.size; nextIndex++) {
			if (copyArray.data[nextIndex] < minValue) {
				minValue = copyArray.data[nextIndex];
				minValueIndex = nextIndex;
			}
		}

		copyArray.data[minValueIndex] = copyArray.data[currentIndex];
		copyArray.data[currentIndex] = minValue;

	}

	return copyArray;

}

//calc_mean: Calculates the mean of a given arrays values. Accepts an array containing a data set of array_t type and returns a double representing the average/mean
//Coder: Zach Francis
double calc_mean(array_t array) {
	long double dataTotal = 0.0;
	for (size_t i = 0; i < array.size; i++) {
		dataTotal += array.data[i];
	}
	dataTotal /= array.size;
	return dataTotal;
}

//calc_median: Calculates the median of a data set. Accepts an array containing data of array_t type and returns a double representing the median
//Coder: Zach Francis
double calc_median(array_t dataArray) {
	double median = 0.0;

	if (dataArray.size % 2 == 1) {
		size_t middleIndex = dataArray.size / 2;
		median = dataArray.data[middleIndex];
	}
	else {
		size_t rightMidIndex = dataArray.size / 2;
		size_t leftMidIndex = rightMidIndex - 1;
		median = (dataArray.data[rightMidIndex] + dataArray.data[leftMidIndex]) / 2;
	}

	return median;
}


//calc_mode: Calculates the mode of a data set. Accepts an array containing data of array_t type and returns a double representing the mode
//Coder: Zach Francis
double calc_mode(array_t dataArray) {
	double mode = 0.0;
	size_t maxCount = 0;
	size_t count = 0;

	for (size_t i = 0; i < dataArray.size; i++) {
		count = 0;

		for (size_t j = 0; j < dataArray.size; j++) {
			if (dataArray.data[j] == dataArray.data[i])
				++count;
		}

		if (count > maxCount) {
			maxCount = count;
			mode = dataArray.data[i];
		}
	}

	if (maxCount == 1)
		mode = -1.0;

	return mode;
}

//calc_variance: Calculates the Variance of a data set. Accepts an array containing data of array_t type and returns a double representing the variance of the data
//Coder: Zach Francis
double calc_variance(array_t dataArray, double mean) {
	double variance = 0.0;
	double sum = 0.0;

	for (size_t i = 0; i < dataArray.size; i++) {
		sum += pow((dataArray.data[i] - mean), 2.0);
	}

	variance = sum / (dataArray.size - 1);
	return variance;
}

//calc_std_dev: Calculates the standard deviation of a data set. Accepts a double representing the variance and returns a double representing the standard deviation
//Coder: Zach Francis
double calc_std_dev(double variance) {
	double stdDeviation = sqrt(variance);
	return stdDeviation;
}
//calc_NB_var: Calculates the Newcomb-Benford variance. Accepts two arrays containg the actual and expected frequencies and returns a double representing the NB variance
//Coder: Zach Francis;
double calc_NB_var(double freqArray[], double expFreq[]) {
	double nbVariance = 0.0;
	double sum = 0.0;
	for (int i = 1; i < 10; i++) {
		sum += pow(((freqArray[i] / expFreq[i]) - 1), 2);
	}
	nbVariance = sum / 9;

	return nbVariance;
}

void print_bars(double  barLength){
	int minLength = 0;
	double remainingLength = 0;
	
	if (barLength == 100)
		minLength = 40;
	else if (barLength > 90)
		minLength = 36;
	else if (barLength > 80)
		minLength = 32;
	else if (barLength > 70)
		minLength = 28;
	else if (barLength > 60)
		minLength = 24;
	else if (barLength > 50)
		minLength = 20;
	else if (barLength > 40)
		minLength = 16;
	else if (barLength > 30)
		minLength = 12;
	else if (barLength > 20)
		minLength = 8;
	else if (barLength > 10)
		minLength = 4;

	for (int i = 1; i <= minLength; i++)
		printf("%c", 254);

	if (barLength != 100) {
		remainingLength = barLength - 10;

		if (remainingLength >= 8.5)
			printf("%c%c%c%c", 254, 254, 254, 254);
		else if (remainingLength < 8.5 && remainingLength >= 6)
			printf("%c%c%c", 254, 254, 254);
		else if (remainingLength < 6 && remainingLength >= 4.5)
			printf("%c%c", 254, 254);
		else if (remainingLength < 4.5 && remainingLength >= 2.5)
			printf("%c", 254);
		else
			printf("");
	}
	printf("\n");
	}

//array_free: frees the memory allocated to array_t type arrays to prevent memory leaks. Accepts pointers to arrays and returns void
void array_free(array_t *pArray) {
	free(pArray->data); //deallocates the memory block
	*pArray = array();  //resets the object to an empty state
}