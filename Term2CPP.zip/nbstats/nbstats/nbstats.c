/* Program: nbstats.c
   Purpose: Accepts a list of positive, real numbers and calculates the
			properties (mean, median, mode, etc) and performs a
			Benford-Newcomb analysis of the list.
   Coder: Zach Francis 0887252
   Date Submitted: Mar. 1st, 2019 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include "array_t.h"

#define _CRT_SECURE_NO_WARNINGS

int main(int argc, char *argv[]) {
	FILE *stream = stdin;
	array_t dataArray = array();
	array_value_t dataValue = 0.0;
	array_t dataCopy = array();
	int freqArray[10] = { 0,0,0,0,0,0,0,0,0,0 };
	array_value_t firstDigit;

	int ch = 0;

	double mean = 0.0;
	double median = 0.0;
	double mode = 0.0;

	double variance = 0.0;
	double stdDeviation = 0.0;

	double actualFreq[10] = { 0,0,0,0,0,0,0,0,0,0 };
	double expectFreq[10] = { 0,0,0,0,0,0,0,0,0,0 };

	double nbVariance = 0.0;
	double nbStdDeviation = 0.0;

	for (int i = 1; i < 10; i++) {
		expectFreq[i] = (log10(1.0 + (1.0 / i))) * 100.0;
	}

	if (argc == 1) {
		printf("Enter positive, non-zero, real numbers for data analysis. Enter -1 to begin analysis:\n");
		while (dataValue != EOF) {
			scanf_s("%lf", &dataValue);
			if (dataValue <= 0) {
				continue;
			}
			else {
				array_push_back(&dataArray, dataValue);
				array_push_back(&dataCopy, dataValue);
			}
		}
	}

	else if (argc == 2) {
		stream = fopen(argv[1], "r");
		if (stream == NULL) {
			printf("Error opening file. Ending program");
			return EXIT_FAILURE;
		}
		else if (stream != NULL) {
			while (fgetc(stream) != EOF) {
				fscanf(stream, "%lf", &dataValue);
				if (dataValue <= 0) 
					continue;
				else{
					array_push_back(&dataArray, dataValue);
					array_push_back(&dataCopy, dataValue);
				}
			}
		}
		fclose(stream);
	}

	else if (argc > 2) {
		printf("Too many arguments passed. Ending program.");
		return EXIT_FAILURE;
	}

	dataCopy = sort_array(dataCopy);

	for (size_t i = 0; i < dataArray.size; i++) {
		firstDigit = dataArray.data[i];
		while (firstDigit >= 10) 
			firstDigit /= 10;
		freqArray[(unsigned int)firstDigit]++;
	}

	for (int i = 1; i < 10; i++) {
		actualFreq[i] = (freqArray[i] * 100.0) / dataArray.size;
	}

	mean = calc_mean(dataArray);
	median = calc_median(dataCopy);
	mode = calc_mode(dataArray);

	variance = calc_variance(dataArray, mean);
	stdDeviation = calc_std_dev(variance);

	//Standard Output
	printf("\nStandard Analysis:\n");
	printf("--------------------\n\n");
	printf("# Elements: %ld\n", dataArray.size);
	printf("Range: [%.2lf ... %.2lf]\n", dataCopy.data[0], dataCopy.data[dataCopy.size - 1]);
	printf("Mean: %.2lf\n", mean);
	printf("Median: %.2lf\n", median);
	printf("Variance: %e\n", variance);
	printf("Stadanard Deviation: %.2lf\n", stdDeviation);
	if (mode == -1)
		printf("Mode: No Mode\n");
	else
		printf("Mode: %.2lf\n", mode);
	for (int i = 1; i < 10; i++) {
		printf("[%d] = %d\n", i, freqArray[i]);
	}

	printf("\n");

	//Newcomb-Benford Output
	printf("Newcomb-Benford's Law Analysis\n");
	for (int i = 0; i <= 60; i++)
		printf("%c", 205);
	printf("\n\n");
	printf("   exp Dig   freq   0  10  20  30  40  50  60  70  80  90 100\n");

	for (int i = 0; i < 19; i++) 
		printf("%c", 196);
	
	printf(" %c", 218);

	for (int i = 0; i < 10; i++)
		printf("%c%c%c%c", 196, 196, 196, 194);

	printf("\n");

	for (int i = 1; i < 10; i++) {
		if (i < 4) {
			printf("%.2lf%c [%d] = %.2lf%c  %c", expectFreq[i], 37, i, actualFreq[i], 37, 179);
			print_bars(actualFreq[i]);
		}
		else {
			printf(" %.2lf%c [%d] = %4.2lf%c  %c", expectFreq[i], 37, i, actualFreq[i], 37, 179);
			print_bars(actualFreq[i]);
		}
	}

	for (int i = 0; i < 19; i++)
		printf("%c", 196);

	printf(" %c", 192);

	for (int i = 0; i < 10; i++)
		printf("%c%c%c%c", 196, 196, 196, 193);

	nbVariance = calc_NB_var(actualFreq, expectFreq);
	nbStdDeviation = sqrt(nbVariance);
	printf("\nNewcomb-Benford Variance: %.5lf%c\n", nbVariance * 100, 37);
	printf("Newcomb-Benford Standard Deviation: %.5lf%c\n", nbStdDeviation * 100, 37);
	if (nbStdDeviation >= 0 && nbStdDeviation < 0.1)
		printf("There is a very strong Newcomb-Benford relationship.\n");
	else if (nbStdDeviation >= 0.1 && nbStdDeviation < 0.2)
		printf("There is a strong Newcomb-Benford relationhip.\n");
	else if (nbStdDeviation >= 0.2 && nbStdDeviation < 0.35)
		printf("There is a moderate Newcomb-Benford relationship.\n");
	else if (nbStdDeviation >= 0.35 && nbStdDeviation < 0.5)
		printf("There is a weak Newcomb-Benford relationship.\n");
	else if (nbStdDeviation >= 0.5)
		printf("There is no Newcomb-Benford relationship.\n");
		

	array_free(&dataArray);
	array_free(&dataCopy);

	return EXIT_SUCCESS;
}