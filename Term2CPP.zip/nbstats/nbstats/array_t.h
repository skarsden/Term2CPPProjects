/* File: array_t.h
   Purpose: Creates an abstract array data type used to create an object
   Coder: Zach Francis */

#include <stdint.h>
#include <stdbool.h>
#include <crtdbg.h>

typedef double array_value_t;

typedef struct array_tag {
	array_value_t *data;   //pointer to dynamic array
	size_t        size;    //tracks number of elements
	size_t		  capacity; //current capacity of array
}array_t;  //data type name for the structure

//declaring functions that can use structures
array_t array();
bool array_push_back(array_t *pArray, array_value_t value);
bool array_resize(array_t *pArray, size_t newSize);
array_t sort_array(array_t copyArray);

double calc_mean(array_t array);
double calc_median(array_t dataArray);
double calc_mode(array_t dataArray);

double calc_variance(array_t dataArray, double mean);
double calc_std_dev(double variance);

double calc_NB_var(double freqArray[], double expFreq[]);

void print_bars(double barLength);

void array_free(array_t *pArray);